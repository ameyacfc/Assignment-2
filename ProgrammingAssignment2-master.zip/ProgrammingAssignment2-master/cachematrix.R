## The first function creates a matrix to cache inverse of the matrix
## The second function computes the inverse of the matrix. If inverse is in cache,
## it is retrieved from the cache.

## A matrix is created to cache inverse of the matrix. 
makeCacheMatrix <- function(x=matrix())
{
  i <- NULL
  set <- function(y)
  {
    x <<- y
    i <<- NULL
  }
  get <- function()x
  setinv <- function(inv) i <<- inv
  getinv <- function() i
  list(set = set, get = get, setinv = setinv, getinv = getinv)
}




## This function calculates the inverse, if inverse is stored in cache, it is
## retrieved from there.
cacheSolve <- function(x, ...)
{
  i <- x$getinv()
  if(!is.null(i))
  {
    message("Getting cached data")
    return(i)
  }
  data <- x$get()
  i <- solve(data, ...)
  x$setinv(i)
  i
}

